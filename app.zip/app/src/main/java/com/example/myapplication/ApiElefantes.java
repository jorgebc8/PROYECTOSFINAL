package com.example.myapplication;


import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.adaptador.RecyclerAdapter;
import com.example.myapplication.io.ConectarApiElefantes;
import com.example.myapplication.modelo.Elefantes;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ApiElefantes extends AppCompatActivity {

    private ListView recView;
    public ArrayList<Elefantes> ElefantesApi = new ArrayList<Elefantes>();

    private RecyclerAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recView = (ListView) findViewById(R.id.recView);

        adapter = new RecyclerAdapter(ElefantesApi);
        recView.setAdapter((ListAdapter) adapter);

        new taskConnections().execute();

    }

    //Al ser una tarea que implica una espera,
// como es la respuesta del servidor, por ello se tiene que llevar a cabo a través de un hilo
// secundario.
    private class taskConnections extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            String result = null;
                    result = ConectarApiElefantes.getRequest();
            return result;
        }


    }
}